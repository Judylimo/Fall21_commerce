import React from 'react'
import Reservationslist from './Reservationslist'



const Details = (props) => {
    const {revId,name,cubicle,sdate,edate,atime,dtime} = props.rev
    const{handleCancelClick}= props.handleCancelClick
    return (
        <tr>
        <td>{revId}</td>
        <td>{name}</td>
        <td>{cubicle}</td>
        <td>{sdate}</td>
        <td>{edate}</td>
        <td> {atime}</td>
        <td> {dtime}</td>
        
    
    <button type = "delete" onClick={()=>handleCancelClick(revId)}>
        Cancel</button>
    </tr>
    )
}

export default Details

/*const Details = (props) => {
    const {revId,name,cubicle,sdate,edate,atime,dtime} = props.rev
    const{handleCancelClick}= props.handleCancelClick
    return (
        */

        /*const Details = ({rev, handleCancelClick}) => {
   
    return (
        <tr>
        <td>{rev.revId}</td>
        <td>{rev.name}</td>
        <td>{rev.cubicle}</td>
        <td>{rev.sdate}</td>
        <td>{rev.edate}</td>
        <td> {rev.atime}</td>
        <td> {rev.dtime}</td>
        */


