
import React from 'react'
import { Container, Nav, Navbar, Button } from 'react-bootstrap'
import {Link} from 'react-router-dom'

const Header = () => {
    return (
    <>
  <Navbar bg ="dark" variant="dark">
    <Container>
    <Navbar.Brand href="#home"> My Reservations</Navbar.Brand>
    <Nav className="me-auto">
    
      <Nav.Link href="#features">Reserve A Cubicle</Nav.Link>
      <Nav.Link href="#pricing">Log Out</Nav.Link>
    </Nav>
      
       

    </Container>
  </Navbar>
  <br />
  </>

    )
}

export default Header
/*<>
    
         <Button variant="success">Reserve a Cubicle</Button>{'  '}
         <Button variant="success">Log out</Button>{'  '}
      </>

    </Nav> */
